# Build a small single-page web app called "FocusBoard" — a mi (copy)


Generated with CODE GIFTZ (BEAN Intelligence).

- Framework: static
- Language: not specified
- Project created: 2026-11-15T03:21:27.857Z
- Last updated: 2026-11-15T03:22:09.992Z
- Recorded project version: 3 (of 3 versions)

## Files

- `NOTICES.md`
- `main.html`
- `vendor/ScrollTrigger.min.js`
- `vendor/gsap.min.js`

## Run (static web project)

Open `main.html` in a browser — no build step is required.

## Licenses

Third-party component notices are in `NOTICES.md`.

## Notes

This archive excludes environment files, secrets, credentials, cookies, dependency folders and build outputs by policy. See `manifest.json` for the exact exclusion list of this export.