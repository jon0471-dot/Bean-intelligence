# Nova Reyes portfolio

M24 isolated fixture export

Generated with CODE GIFTZ (BEAN Intelligence).

- Framework: react
- Language: tsx
- Project created: 2026-11-15T03:34:10.372Z
- Last updated: 2026-11-15T03:34:10.372Z
- Recorded project version: 1

## Files

- `ASSISTANT-MESSAGE.md`
- `App.tsx`
- `NOTICES.md`
- `components/kit/BlurText.tsx`
- `components/kit/Dock.css`
- `components/kit/Dock.tsx`
- `components/kit/GlareHover.css`
- `components/kit/GlareHover.tsx`
- `components/kit/SplitText.tsx`
- `components/kit/SpotlightCard.css`
- `components/kit/SpotlightCard.tsx`
- `components/quick-nav.tsx`
- `data/projects.ts`
- `index.html`
- `index.tsx`
- `lib/motion.ts`
- `package-lock.json`
- `package.json`
- `pages/about.tsx`
- `pages/contact.tsx`
- `pages/home.tsx`
- `pages/not-found.tsx`
- `pages/project-detail.tsx`
- `pages/projects.tsx`
- `styles.css`

## Run (static web project)

Open `index.html` in a browser — no build step is required.

## Package manager detected

`npm` (from the lockfile present in this archive).

## Licenses

Third-party component notices are in `NOTICES.md`.

## Notes

This archive excludes environment files, secrets, credentials, cookies, dependency folders and build outputs by policy. See `manifest.json` for the exact exclusion list of this export.