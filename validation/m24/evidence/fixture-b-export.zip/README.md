# Pulse analytics dashboard

M24 isolated fixture export

Generated with CODE GIFTZ (BEAN Intelligence).

- Framework: react
- Language: tsx
- Project created: 2026-11-15T03:34:10.344Z
- Last updated: 2026-11-15T03:34:10.344Z
- Recorded project version: 1

## Files

- `ASSISTANT-MESSAGE.md`
- `App.tsx`
- `NOTICES.md`
- `components/charts.tsx`
- `components/header.tsx`
- `components/kit/Dock.css`
- `components/kit/Dock.tsx`
- `components/kit/LatticeLoader.css`
- `components/kit/LatticeLoader.tsx`
- `components/kit/SpotlightCard.css`
- `components/kit/SpotlightCard.tsx`
- `components/sidenav.tsx`
- `components/states.tsx`
- `components/table.tsx`
- `data/sample.ts`
- `index.html`
- `index.tsx`
- `lib/motion.ts`
- `package-lock.json`
- `package.json`
- `styles.css`

## Run (static web project)

Open `index.html` in a browser — no build step is required.

## Package manager detected

`npm` (from the lockfile present in this archive).

## Licenses

Third-party component notices are in `NOTICES.md`.

## Notes

This archive excludes environment files, secrets, credentials, cookies, dependency folders and build outputs by policy. See `manifest.json` for the exact exclusion list of this export.