# Nebula landing page

M24 isolated fixture export

Generated with CODE GIFTZ (BEAN Intelligence).

- Framework: react
- Language: tsx
- Project created: 2026-11-15T03:34:10.278Z
- Last updated: 2026-11-15T03:34:10.279Z
- Recorded project version: 1

## Files

- `ASSISTANT-MESSAGE.md`
- `App.tsx`
- `NOTICES.md`
- `components/closing.tsx`
- `components/hero.tsx`
- `components/kit/AnimatedContent.tsx`
- `components/kit/BlurText.tsx`
- `components/kit/CountUp.tsx`
- `components/kit/ScrollReveal.css`
- `components/kit/ScrollReveal.tsx`
- `components/kit/SplitText.tsx`
- `components/kit/VantaBackground.tsx`
- `components/sections.tsx`
- `components/site-nav.tsx`
- `index.html`
- `index.tsx`
- `lib/motion.ts`
- `package-lock.json`
- `package.json`
- `styles.css`
- `types/vanta.d.ts`

## Run (static web project)

Open `index.html` in a browser — no build step is required.

## Package manager detected

`npm` (from the lockfile present in this archive).

## Licenses

Third-party component notices are in `NOTICES.md`.

## Notes

This archive excludes environment files, secrets, credentials, cookies, dependency folders and build outputs by policy. See `manifest.json` for the exact exclusion list of this export.